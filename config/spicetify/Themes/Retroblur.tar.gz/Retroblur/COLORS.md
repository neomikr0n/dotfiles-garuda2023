<h1 align="center">Retroblur Color Styles</h1>
<p align="center">

![Purple](preview/home.png)

![Red](preview/red.png)

![Orange](preview/orange.png)

![Green](preview/green.png)

![Blue](preview/blue.png)
 </p>
