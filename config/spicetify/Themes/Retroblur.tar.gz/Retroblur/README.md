
<h1 align="center">Retroblur</h1>
<p align="center">Spicetify theme with lots of blur and retro elements.<br>
Based on https://github.com/schnensch0/ziro <br>
Copyright © 2022 Motschen - MIT License<br>


![Home](preview/home.png)

![Playlist](preview/playlist.png)

![Synced Lyrics](preview/synced_lyrics.png)

![Missing Lyrics](preview/missing_lyrics.gif)

 </p>

[Preview of the color variations](COLORS.md)
<p align="center">
To change the color of the background, edit the link on the first line of user.css <br>
It's sadly not possible to change the background together with the color scheme automatically due to the limitations of CSS.
 </p>
